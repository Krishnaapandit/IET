﻿
namespace _00StandardDotNetConsoleApp.Logic
{
    internal class Demo
    {
    }
}
