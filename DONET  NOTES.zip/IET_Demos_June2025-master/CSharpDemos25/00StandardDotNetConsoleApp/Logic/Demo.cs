﻿
using System;

namespace _00StandardDotNetConsoleApp.Logic
{
    internal class Demo
    {
        public int i = 100;
        public void Display()
        {
            Console.WriteLine("Value of i: " + i);
        }
    }
}
