﻿using _00StandardDotNetConsoleApp.Logic;
using System;
namespace _00StandardDotNetConsoleApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Demo obj = new Demo();
            obj.i = 200; // Accessing the public field 'i' of the Demo class
            Console.WriteLine("Hello World!Hello World...");
            Console.ReadLine();
            Console.Read();
            Console.ReadKey();
        }
    }
}
